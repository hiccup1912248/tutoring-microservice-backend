package com.hmc.gatewayservice.model;

import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Getter
public class Authorities {

    private String authority;
}