package com.hmc.gatewayservice.util;

public class SecurityConstants {

    public static final String HEADER = "Authorization";
}
