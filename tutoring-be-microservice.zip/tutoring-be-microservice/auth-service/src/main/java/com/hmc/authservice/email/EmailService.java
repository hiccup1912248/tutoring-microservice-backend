package com.hmc.authservice.email;

import com.hmc.authservice.entities.User;

import javax.mail.MessagingException;
import java.util.Map;

public interface EmailService {

    public void sendSimpleMessage(String to, String subject, String text);

    public void sendSimpleMessageUsingTemplate(String to, String subject, String template, Map<String, Object> params) throws MessagingException;

    public void sendMessageWithAttachment(String to, String subject, String text, String pathToAttachment);

    public void sendHtmlMessage(String to, String subject, String htmlMsg);

    public void sendRegistrationConfirmationEmail(User user);
}
