package com.hmc.authservice.email;

import com.hmc.authservice.entities.User;
import com.hmc.authservice.service.impl.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.File;
import java.util.Map;
import java.util.UUID;

@Component
public class EmailServiceImpl implements EmailService {

    @Value("${spring.mail.username}")
    private String sender;

    @Value("${spring.mail.hostUrl}")
    private String hostUrl;

    @Value("${spring.mail.host}")
    private String host;

    @Value("${spring.mail.port}")
    private Integer port;

    @Value("${spring.mail.username}")
    private String username;

    @Value("${spring.mail.password}")
    private String password;

    @Value("${spring.mail.sendGridApiKey}")
    private String SENDGRID_API_KEY;

    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    @Autowired
    private Environment environment;

    @Autowired
    private JavaMailSender emailSender;

    @Autowired
    SpringTemplateEngine templateEngine;


    @Override
    public void sendSimpleMessage(String to, String subject, String text) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(to);
            message.setFrom(sender);
            message.setSubject(subject);
            message.setText(text);
            emailSender.send(message);
        } catch (MailException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void sendSimpleMessageUsingTemplate(String to, String subject, String template, Map<String, Object> params) throws MessagingException {
        MimeMessage message = emailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true, "utf-8");
        Context context = new Context();
        context.setVariables(params);
        String html = templateEngine.process(template, context);
        helper.setTo(to);
        helper.setFrom(sender);
        helper.setText(html, true);
        helper.setSubject(subject);
    }

    @Override
    public void sendMessageWithAttachment(String to, String subject, String text, String pathToAttachment) {
        try {
            MimeMessage message = emailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setTo(to);
            helper.setFrom(sender);
            helper.setSubject(subject);
            helper.setText(text);
            FileSystemResource file = new FileSystemResource(new File(pathToAttachment));
            helper.addAttachment("Invoice", file);
            emailSender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void sendHtmlMessage(String to, String subject, String htmlMsg) {

//        Email from = new Email(username);
//        Email toUser = new Email(to);
//        Content content = new Content("text/html", htmlMsg);
//        Mail mail = new Mail(from, subject, toUser, content);
//        SendGrid sg = new SendGrid(SENDGRID_API_KEY);
//        Request request = new Request();
//        try {
//            request.setMethod(Method.POST);
//            request.setEndpoint("mail/send");
//            request.setBody(mail.build());
//            Response response = sg.api(request);
//            System.out.println(response.getStatusCode());
//            System.out.println(response.getBody());
//            System.out.println(response.getHeaders());
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        try {
            //Spring Framework JavaMailSenderImplementation
            JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
            mailSender.setHost(host);
            mailSender.setPort(port);

            //setting username and password
            mailSender.setUsername(username);
            mailSender.setPassword(password);

            MimeMessage message = emailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, false, "utf-8");
            message.setContent(htmlMsg, "text/html");
            helper.setTo(to);
            helper.setFrom(sender);
            helper.setSubject(subject);
            emailSender.send(message);
        } catch (MailException | MessagingException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void sendRegistrationConfirmationEmail(User user) {
        String token = UUID.randomUUID().toString();
        userDetailsService.createVerificationTokenForUser(token, user);
        String link = String.format(hostUrl + "/%s", token);
        String msg = String.format("<p>Please, follow the link to complete your registration:</p><p><a href=\"%s\">Verify</a></p>", link);
        sendHtmlMessage(user.getEmail(), "Tutoring App: Registration Confirmation", msg);
    }
}
