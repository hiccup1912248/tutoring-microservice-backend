package com.hmc.authservice.response;

import lombok.Data;
import org.springframework.security.core.GrantedAuthority;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

@Data
public class SuccessfulSigninResponse implements Serializable {

    private String id;

    private String useremail;

    private Collection<GrantedAuthority> authorities;

    private String token;

    public SuccessfulSigninResponse(String id, String email, List<GrantedAuthority> authorities, String token) {
        super();
        this.id = id;
        this.useremail = email;
        this.authorities = authorities;
        this.token = token;
    }
}
