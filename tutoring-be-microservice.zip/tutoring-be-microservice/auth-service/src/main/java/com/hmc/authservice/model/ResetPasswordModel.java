package com.hmc.authservice.model;

import lombok.Data;

@Data
public class ResetPasswordModel {

    String id;

    String currentPassword;

    String newPassword;

    String confirmPassword;
}
