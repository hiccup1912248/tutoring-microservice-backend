package com.hmc.authservice.service.impl;

import com.hmc.authservice.constant.TutoringConstant;
import com.hmc.authservice.entities.User;
import com.hmc.authservice.entities.VerificationToken;
import com.hmc.authservice.repository.UserRepository;
import com.hmc.authservice.repository.VerificationTokenRepository;
import com.hmc.authservice.utils.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserDetailsServiceImpl implements UserDetailsService, com.hmc.authservice.service.UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    VerificationTokenRepository tokenRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email).get();
        List<GrantedAuthority> authorities = user.getRoles().stream().map(role -> {
            return new SimpleGrantedAuthority(role.getName());
        }).collect(Collectors.toList());
        return org.springframework.security.core.userdetails.User.withUsername(email).password(user.getPassword()).authorities(authorities).accountExpired(false).accountLocked(false).credentialsExpired(false).disabled(false).build();
    }

    @Override
    public void createVerificationTokenForUser(String token, User user) {
        VerificationToken newToken = new VerificationToken(token, user);
        newToken.setId(CommonUtil.uuidGenerator());
        tokenRepository.save(newToken);
    }

    @Override
    public String validateVerificationToken(String token) {
        Optional<VerificationToken> verificationToken = tokenRepository.findByToken(token);

        if (verificationToken.isPresent()) {
            User user = verificationToken.get().getUser();
            Calendar cal = Calendar.getInstance();
            if (verificationToken.get().getExpiryDate().compareTo(cal.getTime()) < 0) {
                tokenRepository.delete(verificationToken.get());
                return TutoringConstant.TOKEN_EXPIRED;
            }
            user.setEnabled(true);
            tokenRepository.delete(verificationToken.get());
            userRepository.save(user);
            return TutoringConstant.TOKEN_VALID;
        } else {
            return TutoringConstant.TOKEN_INVALID;
        }
    }
}
