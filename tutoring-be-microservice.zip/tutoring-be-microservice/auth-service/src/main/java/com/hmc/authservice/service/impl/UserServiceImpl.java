package com.hmc.authservice.service.impl;

import com.hmc.authservice.constant.TutoringConstant;
import com.hmc.authservice.entities.Role;
import com.hmc.authservice.entities.User;
import com.hmc.authservice.entities.VerificationToken;
import com.hmc.authservice.model.ResetPasswordModel;
import com.hmc.authservice.repository.RoleRepository;
import com.hmc.authservice.repository.UserRepository;
import com.hmc.authservice.repository.VerificationTokenRepository;
import com.hmc.authservice.service.UserService;
import com.hmc.authservice.utils.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Value("${tutoring.app.expiryTimeInMinutes}")
    private Integer expiryTimeInMinutes;

    @Autowired
    private VerificationTokenRepository tokenRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder encoder;

    @Override
    public User userRegister(User user) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
        User savedUser = userRepository.save(user);
        return savedUser;
    }

    @Override
    public User login(User user) {
        Optional<User> users = userRepository.findByEmail(user.getEmail());
        if (users.isPresent()) {
            return null;
        } else {
            if (checkValidPassword(users.get(), user.getPassword())) {
                return users.get();
            }
        }
        return null;
    }

    public boolean checkValidPassword(User user, String oldPassword) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        return passwordEncoder.matches(oldPassword, user.getPassword());
    }

    @Override
    public User registerFromGoogle(User user) {
        Optional<User> users = userRepository.findByEmail(user.getEmail());
        if (!users.isPresent()) {
            user.setPassword(encoder.encode("gauth"));
            user.setId(CommonUtil.uuidGenerator());
            user.setEnabled(false);
            user.setType(0);
            user.setRoles(Arrays.asList(roleRepository.findByName("ROLE_USER")));
            User savedUser = userRepository.save(user);
            return savedUser;
        } else {
            return users.get();
        }
    }

    @Override
    public List<User> list() {
        List<User> list = userRepository.findAll();
        return list;
    }

    @Override
    public User save(User data) {
        Role role = new Role();
        if (data.getType().equals(TutoringConstant.USER_TYPE_PARENT)) {
            role = roleRepository.findByName(TutoringConstant.ROLE_PARENT);
        }
        if (data.getType().equals(TutoringConstant.USER_TYPE_TUTOR)) {
            role = roleRepository.findByName(TutoringConstant.ROLE_TUTOR);
        }
        data.setRoles(Arrays.asList(role));
        User user = userRepository.save(data);
        return user;
    }

    @Override
    public User getById(String id) {
        User user = userRepository.findById(id).get();
        return user;
    }

    @Override
    public List<User> listByType(Integer type) {
        List<User> list = userRepository.findByType(type);
        return list;
    }

    @Override
    public void createVerificationTokenForUser(VerificationToken token) {
        tokenRepository.save(token);
    }

    @Override
    public String validateVerificationToken(String token) {
        Optional<VerificationToken> verificationToken = tokenRepository.findByToken(token);

        if (verificationToken.isPresent()) {
            User user = verificationToken.get().getUser();
            Calendar cal = Calendar.getInstance();
            if (verificationToken.get().getExpiryDate().compareTo(cal.getTime()) < 0) {
                tokenRepository.delete(verificationToken.get());
                return TutoringConstant.TOKEN_EXPIRED;
            }
            user.setEnabled(true);
            tokenRepository.delete(verificationToken.get());
            userRepository.save(user);
            return TutoringConstant.TOKEN_VALID;
        } else {
            return TutoringConstant.TOKEN_INVALID;
        }
    }

    @Override
    public String resetPassword(ResetPasswordModel json) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        Optional<User> user = userRepository.findById(json.getId());
        if (passwordEncoder.matches(json.getCurrentPassword(), user.get().getPassword())) {
            String encodedPassword = passwordEncoder.encode(json.getNewPassword());
            user.get().setPassword(encodedPassword);
            User updatedUser = user.get();
            userRepository.save(updatedUser);
            return "OK";
        } else {
            return "Failed";
        }
    }

    @Override
    public Page<User> findAll(User user, Pageable pageable) {
        return userRepository.findAllBySearchFilter(user.getType(), user.getSubject(), pageable);
    }
}
