package com.hmc.authservice.service;

import com.hmc.authservice.entities.User;
import com.hmc.authservice.entities.VerificationToken;
import com.hmc.authservice.model.ResetPasswordModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface UserService {
    public User userRegister(User user);

    public User login(User user);

    public User registerFromGoogle(User user);

    public List<User> list();

    public List<User> listByType(Integer type);

    public Page<User> findAll(User user, Pageable pageable);

    public User getById(String id);

    public User save(User data);

    public void createVerificationTokenForUser(VerificationToken token);

    public String validateVerificationToken(String token);

    public String resetPassword(ResetPasswordModel json);
}
