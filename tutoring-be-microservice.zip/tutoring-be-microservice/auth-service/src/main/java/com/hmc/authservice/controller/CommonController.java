package com.hmc.authservice.controller;

import com.hmc.authservice.constant.TutoringConstant;
import com.hmc.authservice.exceptions.NotAnImageFileException;
import com.hmc.authservice.utils.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import static org.springframework.http.MediaType.*;

@RestController
@RequestMapping("/common")
public class CommonController {
    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Value("${uploadPath}")
    private String uploadPath;

    @PostMapping("/upload")
    public Response uploadImage(@RequestParam("imageFile") MultipartFile imageFile) {
        try {
            if (!imageFile.isEmpty()) {
                if (!Arrays.asList(IMAGE_JPEG_VALUE, IMAGE_GIF_VALUE, IMAGE_PNG_VALUE)
                        .contains(imageFile.getContentType())) {
                    throw new NotAnImageFileException(imageFile.getOriginalFilename() + TutoringConstant.PLEASE_UPLOAD_AN_IMAGE);
                }
                Path filePath = Paths.get(uploadPath).toAbsolutePath().normalize();
                if (!Files.exists(filePath)) {
                    Files.createDirectories(filePath);
                    LOGGER.info(TutoringConstant.DIRECTORY_CREATED + filePath);
                }
                String filename = "avatar_" + String.valueOf(System.currentTimeMillis()) + "." + "jpg";
                Files.copy(imageFile.getInputStream(), filePath.resolve(filename), REPLACE_EXISTING);
                Response responseData = new Response(HttpStatus.OK.value(), true, "Upload success!", filename);
                return responseData;
            } else {
                Response responseData = new Response(HttpStatus.BAD_REQUEST.value(), false, "Upload failed!");
                return responseData;
            }
        } catch (NotAnImageFileException e) {
            Response responseData = new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, TutoringConstant.NOT_IMAGE_FILE_TYPE);
            return responseData;
        } catch (Exception e) {
            e.printStackTrace();
            Response responseData = new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, "Internal server error!");
            return responseData;
        }
    }

    @GetMapping("download/{filename}")
    public ResponseEntity<Resource> download(@PathVariable("filename") String filename) {
        try {
            Path filePath = Paths.get(uploadPath).toAbsolutePath().normalize();
            File file = new File(filePath.resolve(filename).toUri());
            InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
            return ResponseEntity.ok()
                    .contentLength(file.length())
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(resource);
        } catch (Exception e) {
            return null;
        }
    }
}
