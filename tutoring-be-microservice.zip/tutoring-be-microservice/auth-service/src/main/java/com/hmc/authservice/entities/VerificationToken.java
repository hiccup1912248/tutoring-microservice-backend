package com.hmc.authservice.entities;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

import static com.hmc.authservice.utils.CommonUtil.calculateExpiryDate;

@Entity
@Table(name = "verification_token")
@Data
public class VerificationToken implements Serializable {

    private static final long serialVersionUID = 1L;

    public VerificationToken() {
        super();
    }

    public VerificationToken(String token, User user) {
        this.token = token;
        this.user = user;
        this.expiryDate = calculateExpiryDate(1440);
    }

    @Id
    @Column(nullable = false, updatable = false)
    private String id;

    @Column(name = "token")
    private String token;

    @Column(name = "expiry_date")
    private Date expiryDate;

    @OneToOne(targetEntity = User.class, fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
    @JoinColumn(nullable = false, name = "user_id")
    private User user;
}
