package com.hmc.authservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class NewUser implements Serializable {

    private static final long serialVersionUID = 1L;

    public NewUser(String email, String password, String recaptchaToken) {
        this.email = email;
        this.password = password;
        this.recaptchaToken = recaptchaToken;
    }

    @JsonProperty("email")
    private String email;

    @JsonProperty("password")
    private String password;

    @JsonProperty("recaptcha_token")
    private String recaptchaToken;
}
