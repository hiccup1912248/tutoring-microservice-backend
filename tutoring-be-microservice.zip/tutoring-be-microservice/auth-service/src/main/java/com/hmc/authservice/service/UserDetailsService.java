package com.hmc.authservice.service;

import com.hmc.authservice.entities.User;

public interface UserDetailsService extends org.springframework.security.core.userdetails.UserDetailsService {
    public void createVerificationTokenForUser(String token, User user);

    public String validateVerificationToken(String token);

}
