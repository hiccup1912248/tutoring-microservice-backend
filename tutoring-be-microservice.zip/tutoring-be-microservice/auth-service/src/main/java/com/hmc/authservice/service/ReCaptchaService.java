package com.hmc.authservice.service;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ReCaptchaService {

    private String BASE_VERIFY_URL = "https://www.google.com/recaptcha/api/siteverify";

    @Value("${google.recaptcha.key.site}")
    private String keySite;

    @Value("${google.recaptcha.key.secret}")
    private String keySecret;

    public Boolean validateCaptcha(String token) {
        try {
            String url = String.format(BASE_VERIFY_URL + "?secret=%s&response=%s", keySecret, token);
            HttpResponse<JsonNode> jsonResponse = Unirest.get(url)
                    .header("accept", "application/json")
                    .queryString("apiKey", "123")
                    .asJson();
            return jsonResponse.getBody().getObject().get("success").equals(true);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
