package com.hmc.authservice.controller;

import com.hmc.authservice.constant.TutoringConstant;
import com.hmc.authservice.email.EmailService;
import com.hmc.authservice.entities.User;
import com.hmc.authservice.jwt.JwtProvider;
import com.hmc.authservice.model.LoginUser;
import com.hmc.authservice.model.NewUser;
import com.hmc.authservice.repository.RoleRepository;
import com.hmc.authservice.repository.UserRepository;
import com.hmc.authservice.response.ConnValidationResponse;
import com.hmc.authservice.response.SuccessfulSigninResponse;
import com.hmc.authservice.service.ReCaptchaService;
import com.hmc.authservice.service.UserDetailsService;
import com.hmc.authservice.service.UserService;
import com.hmc.authservice.utils.CommonUtil;
import com.hmc.authservice.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Value("${tutoring.app.authCookieName}")
    private String authCookieName;

    @Value("${tutoring.app.isCookieSecure}")
    private Boolean isCookieSecure = true;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private ReCaptchaService captchaService;

    @Autowired
    private JwtProvider jwtProvider;

    @Autowired
    private PasswordEncoder encoder;


    @PostMapping("/signin")
    public Response login(@RequestBody LoginUser loginRequest, HttpServletResponse response) {
        try {
            Optional<User> userCandidate = userRepository.findByEmail(loginRequest.getEmail());
            if (!captchaService.validateCaptcha(loginRequest.getRecaptchaToken())) {
                Response responseData = new Response(HttpStatus.BAD_REQUEST.value(), false, "Validation failed (ReCaptcha v2)");
                return responseData;
            } else if (userCandidate.isPresent()) {
                User user = userCandidate.get();

                if (!user.getEnabled()) {
                    Response responseData = new Response(HttpStatus.UNAUTHORIZED.value(), false, "Account is not verified yet! Please, follow the link in the confirmation email.");
                    return responseData;
                }
                UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword());
                Authentication authentication = authenticationManager.authenticate(usernamePasswordAuthenticationToken);
                SecurityContextHolder.getContext().setAuthentication(authentication);
                String jwt = jwtProvider.generateJwtToken(user.getEmail());
                Cookie cookie = new Cookie(authCookieName, jwt);
                cookie.setMaxAge(jwtProvider.jwtExpiration);
                cookie.setSecure(isCookieSecure);
                cookie.setHttpOnly(true);
                cookie.setPath("/");
                response.addCookie(cookie);
                List<GrantedAuthority> authorities = user.getRoles().stream().map(role -> {
                    return new SimpleGrantedAuthority(role.getName());
                }).collect(Collectors.toList());
                Response responseData = new Response(HttpStatus.OK.value(), true, "Sign in success!", new SuccessfulSigninResponse(user.getId(), user.getEmail(), authorities, jwt));
                return responseData;
            } else {
                Response responseData = new Response(HttpStatus.BAD_REQUEST.value(), false, "User not found!");
                return responseData;
            }
        }catch(BadCredentialsException be) {
            Response responseData = new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, "Password is incorrect!");
            return responseData;
        }
        catch (Exception e) {
            Response responseData = new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, "Internal server error!");
            return responseData;
        }
    }

    @PostMapping("signup")
    public Response register(@RequestBody NewUser newUser) {
        Optional<User> userCandidate = userRepository.findByEmail(newUser.getEmail());
        if (!captchaService.validateCaptcha(newUser.getRecaptchaToken())) {
            Response responseData = new Response(HttpStatus.BAD_REQUEST.value(), false, "Validation failed (ReCaptcha v2)");
            return responseData;
        } else if (userCandidate.isPresent()) {
            Response responseData = new Response(HttpStatus.BAD_REQUEST.value(), false, "Your email is already taken!");
            return responseData;
        }

        try {
            User user = new User();
            user.setId(CommonUtil.uuidGenerator());
            user.setEmail(newUser.getEmail());
            user.setPassword(encoder.encode(newUser.getPassword()));
            user.setEnabled(false);
            user.setType(0);
            user.setRoles(Arrays.asList(roleRepository.findByName("ROLE_USER")));
            User registeredUser = userRepository.save(user);
            emailService.sendRegistrationConfirmationEmail(registeredUser);
        } catch (Exception e) {
            Response responseData = new Response(HttpStatus.SERVICE_UNAVAILABLE.value(), false, "Server error. Please, contact site owner");
            return responseData;
        }
        Response responseData = new Response(HttpStatus.OK.value(), true, "Please, follow the link in the confirmation email to complete the registration.");
        return responseData;
    }

    @PostMapping("register-from-google")
    public Response registerFromGoogle(@RequestBody User user, HttpServletResponse response) {
        try {
            user.setType(0);
            user.setEnabled(false);
            User savedUser = userService.registerFromGoogle(user);

            UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(savedUser.getEmail(), "gauth");
            Authentication authentication = authenticationManager.authenticate(usernamePasswordAuthenticationToken);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            String jwt = jwtProvider.generateJwtToken(user.getEmail());
            Cookie cookie = new Cookie(authCookieName, jwt);
            cookie.setMaxAge(jwtProvider.jwtExpiration);
            cookie.setSecure(isCookieSecure);
            cookie.setHttpOnly(true);
            cookie.setPath("/");
            response.addCookie(cookie);
            List<GrantedAuthority> authorities = savedUser.getRoles().stream().map(role -> {
                return new SimpleGrantedAuthority(role.getName());
            }).collect(Collectors.toList());
            Response responseData = new Response(HttpStatus.OK.value(), true, "Sign in success!", new SuccessfulSigninResponse(savedUser.getId(), savedUser.getEmail(), authorities, jwt));
            return responseData;
        } catch (Exception e) {
            e.printStackTrace();
            Response responseData = new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, "Internal server error!");
            return responseData;
        }
    }

    @PostMapping("registration-confirm")
    public Response confirmRegistration(@RequestParam("token") String token) {
        String verifyResult = userService.validateVerificationToken(token);
        switch (verifyResult) {
            case TutoringConstant.TOKEN_VALID:
                return new Response(HttpStatus.OK.value(), true, "Registration confirmed!");
            case TutoringConstant.TOKEN_INVALID:
                return new Response(HttpStatus.BAD_REQUEST.value(), false, "Token is invalid!");
            case TutoringConstant.TOKEN_EXPIRED:
                return new Response(HttpStatus.UNAUTHORIZED.value(), false, "Token is invalid!");
        }
        return new Response(HttpStatus.SERVICE_UNAVAILABLE.value(), false, "Server error. Please, contact site owner");
    }

    @GetMapping("validate-token")
    public ResponseEntity<ConnValidationResponse> validateGet() {
        return ResponseEntity.ok(ConnValidationResponse.builder().status("OK").methodType(HttpMethod.GET.name())
                .isAuthenticated(true).build());
    }
}
