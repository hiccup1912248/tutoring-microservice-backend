package com.hmc.authservice.constant;

public class TutoringConstant {
    public static Integer CODE_OK = 200;
    public static Integer CODE_ERROR = 505;
    public static Integer CODE_SERVER_ERROR = 500;
    public static final String SUCCESS = "Success";
    public static final String ERROR = "Error";
    public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
    public static final String LOG_IN_SUCCESS = "Log In Success";
    public static final String SIGN_UP_SUCCESS = "Sign Up Success";
    public static final String TOKEN_EXPIRED = "Token is expired";
    public static final String TOKEN_VALID = "Token is valid";
    public static final String TOKEN_INVALID = "Token is invalid";
    public static final String PLEASE_UPLOAD_AN_IMAGE = "is not an image file. Please upload an image";
    public static final String DIRECTORY_CREATED = "Created directory for: ";
    public static final String NOT_IMAGE_FILE_TYPE = "This is not image file. Please select image file type.";
    public static final String ROLE_ADMIN = "ADMIN";
    public static final String ROLE_PARENT = "PARENT";
    public static final String ROLE_TUTOR = "TUTOR";
    public static final Integer USER_TYPE_ADMIN = 2;
    public static final Integer USER_TYPE_PARENT = 0;
    public static final Integer USER_TYPE_TUTOR = 1;
}
