package com.hmc.commonservice.service.impl;

import com.hmc.commonservice.constant.TutoringConstant;
import com.hmc.commonservice.entities.Role;
import com.hmc.commonservice.entities.User;
import com.hmc.commonservice.model.ResetPasswordModel;
import com.hmc.commonservice.repository.RoleRepository;
import com.hmc.commonservice.repository.UserRepository;
import com.hmc.commonservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Override
    public User save(User data) {
        Role role = new Role();
        if (data.getType().equals(TutoringConstant.USER_TYPE_PARENT)) {
            role = roleRepository.findByName(TutoringConstant.ROLE_PARENT);
        }
        if (data.getType().equals(TutoringConstant.USER_TYPE_TUTOR)) {
            role = roleRepository.findByName(TutoringConstant.ROLE_TUTOR);
        }
        data.setRoles(Arrays.asList(role));
        User user = userRepository.save(data);
        return user;
    }

    @Override
    public User getById(String id) {
        User user = userRepository.findById(id).get();
        return user;
    }

    @Override
    public String resetPassword(ResetPasswordModel json) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        Optional<User> user = userRepository.findById(json.getId());
        if (passwordEncoder.matches(json.getCurrentPassword(), user.get().getPassword())) {
            String encodedPassword = passwordEncoder.encode(json.getNewPassword());
            user.get().setPassword(encodedPassword);
            User updatedUser = user.get();
            userRepository.save(updatedUser);
            return "OK";
        } else {
            return "Failed";
        }
    }

    @Override
    public Page<User> findAll(User user, Pageable pageable) {
        return userRepository.findAllBySearchFilter(user.getType(), user.getSubject(), pageable);
    }
}
