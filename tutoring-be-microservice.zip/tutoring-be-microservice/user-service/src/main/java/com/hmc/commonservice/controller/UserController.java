package com.hmc.commonservice.controller;

import com.hmc.commonservice.entities.User;
import com.hmc.commonservice.model.ResetPasswordModel;
import com.hmc.commonservice.service.UserService;
import com.hmc.commonservice.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;


    @GetMapping("/list")
    public Response listByType(User searchForm,
                               @RequestParam(defaultValue = "0") int page,
                               @RequestParam(defaultValue = "5") int size) {
        try {
            Pageable paging = PageRequest.of(page, size);
            Page<User> pageUser = userService.findAll(searchForm, paging);
            Map<String, Object> responseObject = new HashMap<>();
            responseObject.put("list", pageUser.getContent());
            responseObject.put("currentPage", pageUser.getNumber());
            responseObject.put("totalItems", pageUser.getTotalElements());
            responseObject.put("totalPages", pageUser.getTotalPages());
            Response responseData = new Response(HttpStatus.OK.value(), true, "user data", responseObject);
            return responseData;
        } catch (Exception e) {
            Response responseData = new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, "Internal server error!");
            return responseData;
        }
    }

    @GetMapping("/get")
    public Response get(User userParam) {
        try {
            User user = userService.getById(userParam.getId());
            Response responseData = new Response(HttpStatus.OK.value(), true, "user data", user);
            return responseData;
        } catch (Exception e) {
            Response responseData = new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, "Internal server error!");
            return responseData;
        }
    }

    @PostMapping("/save")
    public Response save(@RequestBody User data) {
        try {
            User savedUser = userService.save(data);
            Response responseData = new Response(HttpStatus.OK.value(), true, "save success", savedUser);
            return responseData;
        } catch (Exception e) {
            Response responseData = new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, "Internal server error!");
            return responseData;
        }
    }

    @PostMapping("/resetPassword")
    public Response resetPassword(@RequestBody ResetPasswordModel json) {
        try {
            String status = userService.resetPassword(json);
            if (status.equals(new String("OK"))) {
                Response responseData = new Response(HttpStatus.OK.value(), true, "New password successfully updated.");
                return responseData;
            } else {
                Response responseData = new Response(HttpStatus.BAD_REQUEST.value(), false, "Current password incorrect.");
                return responseData;
            }
        } catch (Exception e) {
            Response responseData = new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), false, "Internal server error!");
            return responseData;
        }
    }
}
