package com.hmc.commonservice.utils;

import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

public class CommonUtil {

    public static String uuidGenerator() {
        return UUID.randomUUID().toString();
    }

    public static Date calculateExpiryDate(Integer expiryTimeInMinutes) {
        Calendar cal = Calendar.getInstance();
        cal.getTime();
        cal.add(Calendar.MINUTE, expiryTimeInMinutes);
        return cal.getTime();
    }
}
