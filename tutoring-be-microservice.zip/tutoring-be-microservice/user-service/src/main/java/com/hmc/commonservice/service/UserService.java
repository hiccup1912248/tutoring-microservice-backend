package com.hmc.commonservice.service;

import com.hmc.commonservice.entities.User;
import com.hmc.commonservice.model.ResetPasswordModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserService {

    public Page<User> findAll(User user, Pageable pageable);

    public User getById(String id);

    public User save(User data);

    public String resetPassword(ResetPasswordModel json);
}
