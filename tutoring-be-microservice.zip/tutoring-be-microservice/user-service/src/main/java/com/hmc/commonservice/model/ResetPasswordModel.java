package com.hmc.commonservice.model;

import lombok.Data;

@Data
public class ResetPasswordModel {

    String id;

    String currentPassword;

    String newPassword;

    String confirmPassword;
}
